Copy the following files into this directory:
- spring.jar
- commons-logging.jar
- servlet-api.jar
