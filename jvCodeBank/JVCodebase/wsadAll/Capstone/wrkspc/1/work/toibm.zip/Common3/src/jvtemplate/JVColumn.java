
package jvtemplate;

public class JVColumn {
	private String m_strFile = null;
	public JVColumn (String strFile) {m_strFile = strFile;}
	public String getFile() {return m_strFile;}
}

