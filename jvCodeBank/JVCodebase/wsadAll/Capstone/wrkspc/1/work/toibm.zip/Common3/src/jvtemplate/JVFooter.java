
package jvtemplate;

public class JVFooter {
	private String m_strFile = null;
	public JVFooter () {}
	public String getFile() {return m_strFile;}
	public void setFile (String strFile) {m_strFile = strFile;}
}

