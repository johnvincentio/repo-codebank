
package jvtemplate;

public class JVHeader {
	private String m_strFile = null;
	public JVHeader () {}
	public String getFile() {return m_strFile;}
	public void setFile (String strFile) {m_strFile = strFile;}
}

