package com.corejsf.j2me;

public class CommandTag extends J2meComponentTag {   
   public String getComponentType() { return "javax.faces.Command"; }  
   public String getRendererType() { return "com.corejsf.j2me.Command"; } 
}
