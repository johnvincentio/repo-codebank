package com.corejsf.j2me;

public class FormTag extends J2meComponentTag {   
   public String getComponentType() { return "javax.faces.Form"; }  
   public String getRendererType() { return "com.corejsf.j2me.Form"; } 
}
