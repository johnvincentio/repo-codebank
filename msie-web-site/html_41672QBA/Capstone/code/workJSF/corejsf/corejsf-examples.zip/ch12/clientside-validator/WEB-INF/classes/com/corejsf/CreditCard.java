package com.corejsf;

public class CreditCard {
   public CreditCard(String number) { this.number = number; }
   public String toString() { return number; }
   private String number;
}
