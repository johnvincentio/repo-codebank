package com.corejsf;

public class UserBean {
   public String getId() { return id; }
   public void setId(String newValue) { id = newValue; }

   private String id;
}
