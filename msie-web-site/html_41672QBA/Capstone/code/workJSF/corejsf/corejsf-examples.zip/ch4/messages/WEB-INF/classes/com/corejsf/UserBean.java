package com.corejsf;

public class UserBean {
   private String name;
   private int age;
   
   // PROPERTY: name
   public String getName() { return name; } 
   public void setName(String newValue) { name = newValue; }
   
   // PROPERTY: age
   public int getAge() { return age; }
   public void setAge(int newValue) { age = newValue; }
}
