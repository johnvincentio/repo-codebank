package com.corejsf;

public class CreditCard {
   private String number;

   public CreditCard(String number) { this.number = number; }
   public String toString() { return number; }
}
