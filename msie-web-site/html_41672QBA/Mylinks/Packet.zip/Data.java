
public class Data {
	private String fname;
	private String lname;
	public Data (String fname, String lname) {
		this.fname = fname; this.lname = lname;
	}
	public String getFname() {return fname;}
	public String getLname() {return lname;}
	public String toString() {return fname + ":" + lname;}
}

