
public class EjbData {
	private int key;
	private String fname;
	private String lname;
	private int id;
	public EjbData (int key, String fname, String lname, int id) {
		this.key = key;
		this.fname = fname;
		this.lname = lname;
		this.id = id;
	}
	public int getKey() {return key;}
	public String getFname() {return fname;}
	public String getLname() {return lname;}
	public int getId() {return id;}
	public String toString() {return key + ":" + fname + ":" + lname
			+ ":" + id;}
}

