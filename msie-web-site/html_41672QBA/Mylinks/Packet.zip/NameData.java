
import java.util.HashMap;

public class NameData {
	public NameData () {}

	public Packet getData (int nKey) {
		return (new NameEjbData()).getData (nKey, new Packet());
	}
	public Packet getData1 (int nKey) {
		NameEjbData ejbNameData = new NameEjbData();
		EjbData ejbData;
		Packet packet = new Packet();
		packet = ejbNameData.getData(nKey, packet);
		if (! packet.isError()) {
			ejbData = (EjbData) packet.getNextData();
			packet.addData (new Data(ejbData.getFname(), ejbData.getLname()));
			packet.addData (new Data2(
				ejbData.getFname() + " " + ejbData.getLname(), 
				ejbData.getId()));
			packet.resetDataPos();
		}
		return packet;
	}
	public Packet getData2 (int nKey) {
		NameEjbData ejbNameData = new NameEjbData();
		EjbData ejbData;
		Packet packet = new Packet();
		packet = ejbNameData.getData(nKey, packet);
		if (! packet.isError()) {
			ejbData = (EjbData) packet.getNextData();
			Data data = new Data(ejbData.getFname(), ejbData.getLname());
			Data2 data2 = new Data2(
				ejbData.getFname() + " " + ejbData.getLname(), 
				ejbData.getId());
			packet.resetData();
			packet.addData (data);
			packet.addData (data2);
			packet.resetDataPos();
		}
		return packet;
	}
}

