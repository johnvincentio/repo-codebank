
import java.util.HashMap;

public class NameEjbData {
	HashMap m_hashMap = new HashMap();	// dummy up a data store
	public NameEjbData () {
		add (1,"abc","ied",13);	 // create some data
		add (2,"ebc","gdf",43);
		add (3,"gbc","tev",53);
		add (4,"fbc","kjl",63);
		add (5,"hbc","dej",23);
	}
	private void add (int nKey, String s1, String s2, int nId) {
		m_hashMap.put (Integer.toString(nKey), new EjbData (nKey, s1, s2, nId));
	}

	public Packet getData (int nKey, Packet packet) {
		EjbData data =  (EjbData) m_hashMap.get (Integer.toString(nKey));
		if (data == null) {
			packet.addError ("Key "+nKey+" does not exist");
			packet.addError ("Error 2");	// dummy up some messages
			packet.addError ("Error 3");
			packet.addError ("Error 4");
		}
		else
			packet.addData (data);
		return packet;
	}
}

