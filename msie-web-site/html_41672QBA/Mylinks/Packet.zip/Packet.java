
import java.util.*;

public class Packet {
	private Data m_data;
	private Error m_error;

	public Packet () {resetData(); resetError();}
	public void resetData() {m_data = new Data();}
	public void resetError() {m_error = new Error();}

	public void addData (Object obj) {m_data.add (obj);}
	public Object getNextData() {return m_data.getNext();}
	public void resetDataPos() {m_data.resetDataPos();}

	public void addError (String msg) {m_error.add(msg);}
	public String getNextError() {return m_error.getNext();}
	public boolean isError() {return m_error.isError();}

	public class Data {
		private ArrayList m_arData;
		private int m_nPos;

		public Data () {
			m_arData = new ArrayList();
			resetDataPos();
		}
		public void resetDataPos() {m_nPos = -1;}
		public void add (Object obj) {m_arData.add (obj);}
		public Object getNext() {
			if (++m_nPos < m_arData.size())
				return get(m_nPos);
			else
				return null;
		}
		private Object get(int m_nPos) {return (Object) m_arData.get(m_nPos);}
	}

	public class Error {
		private ArrayList m_arError;
		private boolean m_bError = false;
		private int m_nPos;

		public Error () {
			m_arError = new ArrayList();
			m_nPos = -1;
		}
		public void add (String msg) {m_arError.add (msg); setError();}
		public boolean isError() {return m_bError;}
		public String getNext() {
			if (++m_nPos < m_arError.size())
				return get(m_nPos);
			else
				return null;
		}
		private String get(int m_nPos) {return (String) m_arError.get(m_nPos);}
		private void setError() {m_bError = true;}
	}
}

