
public class Test {
	public static void main (String[] args) {
		Test test = new Test();
		test.doTest(1);
		test.doTest1(3);
		test.doTest2(5);
		test.doTest(9);
	}
	private void doTest(int nKey) {
		System.out.println (">>> doTest");
		Packet packet = (new NameData()).getData(nKey);
		doResults (packet);
		System.out.println ("<<< doTest");
	}
	private void doTest1(int nKey) {
		System.out.println (">>> doTest1");
		Packet packet = (new NameData()).getData1(nKey);
		doResults (packet);
		System.out.println ("<<< doTest1");
	}
	private void doTest2(int nKey) {
		System.out.println (">>> doTest2");
		Packet packet = (new NameData()).getData2(nKey);
		doResults (packet);
		System.out.println ("<<< doTest2");
	}
	private void doResults(Packet packet) {
		String msg;
		Object obj;

		if (packet.isError()) {
			while ((msg = packet.getNextError()) != null) {
				System.out.println ("MSG :"+msg+":");
			}
		}
		else {
			while ((obj = packet.getNextData()) != null) {
				if (obj instanceof Data) {
					System.out.println ("Data: First "+((Data)obj).getFname()+
						" Last "+((Data)obj).getLname());
				}
				else if (obj instanceof Data2) {
					System.out.println ("Data2: Name "+((Data2)obj).getName()+
						" Id "+((Data2)obj).getId());
				}
				else if (obj instanceof EjbData) {
					System.out.println ("EjbData:" +
						" Key " + ((EjbData)obj).getKey() + 
						" Fname " + ((EjbData)obj).getFname() +
						" Lname " + ((EjbData)obj).getLname() +
						" Id " + ((EjbData)obj).getId());
				}
			}
		}
	}
}

