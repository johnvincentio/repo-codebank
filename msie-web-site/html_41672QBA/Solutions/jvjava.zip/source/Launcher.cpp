
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "resource.h"
#include <stdlib.h>
#include <stdio.h>

#define JV_MSG WM_USER+1	// make up a message after windows messages

char *getnextitem (char *, char *);
int jvlenc (char *);
void noldblk (char *);
void nonewline (char *);
void noquotes (char *);
void notrblk (char *);
void noupper (char *);
void jvMessageBox(char *, char *);
int jvStartProcess (char *);
int doTheApp (char *);

LRESULT CALLBACK WndProc (HWND, UINT, WPARAM, LPARAM);

static char *CmdLine;

int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow) {
	static char szAppName[] = "jvjava";
	HICON       hIcon;
	HWND        hwnd;
	MSG         msg;
	WNDCLASSEX  wndclass;

	CmdLine = lpCmdLine;	// keep the command line

	hIcon = LoadIcon (hInstance,(LPCTSTR)IDI_ICON2);	// want this icon for the .exe
	wndclass.cbSize        = sizeof (wndclass);
	wndclass.style         = CS_HREDRAW | CS_VREDRAW;
	wndclass.lpfnWndProc   = WndProc;
	wndclass.cbClsExtra    = 0;
	wndclass.cbWndExtra    = 0;
	wndclass.hInstance     = hInstance;
	wndclass.hIcon         = hIcon;
	wndclass.hCursor       = LoadCursor (NULL, IDC_ARROW);
	wndclass.hbrBackground = (HBRUSH) GetStockObject (WHITE_BRUSH);
	wndclass.lpszMenuName  = NULL;
	wndclass.lpszClassName = szAppName;
	wndclass.hIconSm       = hIcon;

	RegisterClassEx (&wndclass);
	hwnd = CreateWindow (szAppName,   // window class name
				"Java Application Launcher",           // window caption
				WS_OVERLAPPEDWINDOW,     // window style
				CW_USEDEFAULT,           // initial x position
				CW_USEDEFAULT,           // initial y position
				CW_USEDEFAULT,           // initial x size
				CW_USEDEFAULT,           // initial y size
				NULL,                    // parent window handle
				NULL,                    // window menu handle
				hInstance,               // program instance handle
				NULL) ;		             // creation parameters
//	ShowWindow (hwnd, nCmdShow);	// useful if in trouble!
	ShowWindow (hwnd, SW_HIDE);
	UpdateWindow (hwnd);

	if (! PostMessage (hwnd, JV_MSG, 0, 0)) {	// post message to myself!
		jvMessageBox ("Error","postmessage failed");
	}
	else {
		while (GetMessage (&msg, NULL, 0, 0)) {	// handle the message
			TranslateMessage (&msg);
			DispatchMessage (&msg);
		}
	}
	return msg.wParam;
}

LRESULT CALLBACK WndProc (HWND hwnd, UINT iMsg, WPARAM wParam, LPARAM lParam)
{
	switch (iMsg)
	{
	case WM_CREATE:
		return 0;
	case JV_MSG:
		(void) doTheApp (CmdLine);
		PostQuitMessage(0);		// comment out if app needs to stay up!
		return 0;
	case WM_DESTROY:
		PostQuitMessage(0);
		return 0;
	}
	return DefWindowProc (hwnd, iMsg, wParam, lParam);
}
int doTheApp (char *cmdLine) {
	FILE* fp_in;
	char chbuf[2000], *sptr, ch1[100], chcmd[1000], ch2[100];

	strcpy (chbuf,cmdLine);	// get parameter file
	noquotes (chbuf); noldblk (chbuf); notrblk (chbuf);	// clean up the name

	if (! (fp_in=fopen(chbuf,"r"))) {	// open parameter file
		char temp[1000];
		sprintf(temp,"Could not find file %s",chbuf);
		MessageBox(NULL, temp,"Error loading configuration file", MB_OK);
		return 1;
	}
	while (fgets (chbuf,1999,fp_in)) {	// read the parameter file
		sptr = chbuf;
		nonewline(sptr); notrblk(sptr);	// clean up input
		if (*sptr == 0) continue;		// check for nothing left
		sptr = getnextitem (sptr,ch1);	// get command type
		noupper(ch1);
		if (strcmp(ch1,"env") == 0) {	// set environment variable
			sptr = getnextitem (sptr,ch1);	// name
			sptr = getnextitem (sptr,ch2);	// value
			strcpy (chbuf,ch1); strcat (chbuf,"="); strcat (chbuf,ch2);
			_putenv(chbuf);
		}
		else if (strcmp(ch1,"run") == 0) {	// get command line
			sptr = getnextitem(sptr,chcmd);
		}
	}
//	char thecwd[1000]; _getcwd(thecwd,1000);	// not in use

	if (jvStartProcess(chcmd) != 0)	 {	// start the program
		sprintf(chbuf,"Could not start %s",chcmd);
		MessageBox(NULL,chbuf,"Error starting application", MB_OK);
	}
	return 0;
}
int jvStartProcess (char *chcmd) {
   PROCESS_INFORMATION piProcInfo;
   STARTUPINFO         suiStartInfo;
   DWORD               dwCreate;
   BOOL                fSuccess;

   suiStartInfo.cb = sizeof (STARTUPINFO);
   suiStartInfo.lpReserved = NULL;
   suiStartInfo.lpDesktop = NULL;
   suiStartInfo.lpTitle = NULL;
   suiStartInfo.dwX = 0;
   suiStartInfo.dwY = 0;
   suiStartInfo.dwXSize = 0;
   suiStartInfo.dwYSize = 0;
   suiStartInfo.dwXCountChars = 0;
   suiStartInfo.dwYCountChars = 0;
   suiStartInfo.dwFillAttribute = 0;
   suiStartInfo.dwFlags = 0;
   suiStartInfo.wShowWindow = 0;
   suiStartInfo.cbReserved2 = 0;
   suiStartInfo.lpReserved2 = NULL;
   dwCreate = 0;
   fSuccess = CreateProcess (NULL,
                             chcmd, NULL, NULL, FALSE,
                             dwCreate, NULL, NULL,
                             &suiStartInfo, &piProcInfo);	// start the Java App
	if (! fSuccess) return 1; 
	return 0;
}
void jvMessageBox(char *chHdr, char *chMsg) {	// messages for the user
    MessageBox(NULL, chMsg, chHdr, MB_OK);
}
char *getnextitem (char *pptr, char *rptr) {	// parse the parameter file (CSV format)
   *rptr = 0;
   for ( ; ; ) {
      if (*pptr == ',') {
         pptr++;
         *rptr = 0;
         break;
      }
      *rptr = *pptr;
      if (*rptr == 0) break;
      rptr++; pptr++;
   }
   return (pptr);
}
int jvlenc (char *cptr)
{
   char *lstr;

   for (lstr=cptr; *lstr != 0; lstr++);
   if (lstr <= cptr) return (0);            /* null string */
   while (--lstr > cptr && *lstr == ' ');
   return ((*lstr == ' ') ? 0 : lstr - cptr + 1);
}
void noldblk (char *cptr) {
   char *sptr, *lptr;

   for (lptr=cptr; *lptr == ' '; lptr++);
   if (lptr > cptr)    {
	   for (sptr=cptr; ; sptr++, lptr++) {
         *sptr = *lptr;
         if (*sptr == 0) break;
      }
   }
}
void nonewline (char *cptr) {
   char *lptr;
   for (lptr=cptr; *lptr != 0; lptr++)
      if (*lptr == '\n') *lptr = ' ';
}
void noquotes (char *cptr) {
	char *lptr;
	for (lptr=cptr; *lptr != 0; lptr++)
		if (*lptr == '"') *lptr = ' ';
}
void notrblk (char *cptr) {
   char *lptr;
   int num;

   num = jvlenc (cptr);
   lptr = cptr + num;
   *lptr = 0;
}
void noupper (char *cptr) {
   char *lptr;

   for (lptr = cptr; *lptr != 0; lptr++) {
		if (*lptr >= 'A' && *lptr <= 'Z') *lptr+=40;	// qndirty
   }
}