
package com.idc.knight;

public class Board implements Constants {
	private Square[][] m_squares;
	public Board() {
		m_squares = new Square[XLIMIT][YLIMIT];
		for (int i=0; i<XLIMIT; i++) {
			for (int j=0; j<YLIMIT; j++)
				m_squares[i][j] = new Square(new Pair(i,j));
		}
	}
	private Square getSquare (int x, int y) {return m_squares[x][y];}
	private Square getSquare (final Pair pair) {
		return getSquare(pair.getX(),pair.getY());
	}
	public int getMoveNumber(int i, int j) {
		return getSquare(i,j).getMoveNumber();
	}
	public boolean isEmpty(final Pair pair) {
		return getSquare(pair).isEmpty();
	}
	public int getMaxMoves(final Pair pair) {
		return getSquare(pair).getMaxMoves();
	}
	public Pair getThisMove(final Pair pair, int i) {
		return getSquare(pair).getThisMove(i);
	}
	public void addThisMove(final Pair pair, int move) {
		getSquare(pair).setMoveNumber(move);
		handleExits(pair,true);
	}
	public void deleteThisMove(final Pair pair) {
		getSquare(pair).setMoveNumber(0);
		handleExits(pair,false);
	}
	private void handleExits(final Pair pair, boolean bAdd) {
		int nMax = getMaxMoves(pair);
		Pair newPair;
		for (int i = 0; i < nMax; i++) {
			newPair = getThisMove(pair, i);
			if (bAdd) getSquare(newPair).decrementExits();
			else getSquare(newPair).incrementExits();
		}
	}
//
// check the board for an empty square with zero exits
//
	public boolean isImpossibleSituation (final Pair pair) {
		boolean bReturn = false;
		for (int i=0; i<XLIMIT; i++) {
			for (int j=0; j<YLIMIT; j++) {
//				Debug.println(getSquare(i,j).show());
				if (getSquare(i,j).isEmpty() &&
					getSquare(i,j).getExits() < 1) {
//						bReturn = false;		// PUT THIS BACK
						bReturn = true;
//						Debug.println("Move "+pair.getX()+","+pair.getY()+
//							" Isolated: "+i+","+j);
				}
			}
		}
		return bReturn;
	}
}

