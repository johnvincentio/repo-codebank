
package com.idc.knight;

public interface Constants {
	final int XLIMIT = 8;
	final int YLIMIT = 8;
	final int XYLIMIT = XLIMIT * YLIMIT;
	final int[] XINC = {1,2,2,1,-1,-2,-2,-1};
	final int[] YINC = {2,1,-1,-2,-2,-1,1,2};
	final int MAXMOVETYPES = 8;
}

