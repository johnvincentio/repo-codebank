
package com.idc.knight;

public class Game implements Constants {
	public Game() {
		Output.setFile ("jv.txt",true);	// flush = true
		Debug.setFile ("debug.txt",false);	// append = false
	}
	private void init (String[] args) {
		if (args[0].toLowerCase().equals("all")) {
			System.out.println("allMain");
			for (int x = 0; x < XLIMIT; x++) {
				for (int y = 0; y < YLIMIT; y++) start(new Pair(x,y));
			}
			Output.timing ("There are no more possible solutions. Exiting...");
			Output.flush();
		}
		else {
			System.out.println("oneMain");
			start(new Pair(Integer.parseInt(args[0]),Integer.parseInt(args[1])));
		}
	}
	private void start (final Pair pair) {
		Board board = new Board();
		Debug.timing("Starting ("+pair.getX()+","+pair.getY()+")");
		nextMove (1,pair,board);
		Debug.timing("Finished ("+pair.getX()+","+pair.getY()+")");
		Output.flush();
	}
	private void nextMove (int move, final Pair pair, Board board) {
		board.addThisMove(pair, move);
		if (move >= XYLIMIT) {
			printBoard (board);
			System.out.println("end of a run");
			Debug.println("end of a run");
		}
//
// look for impossible situation
//
		if (isImpossibleSituation (pair,board)) {
//			traceBoard("(1) impossible;",move,pair,board);
//			Debug.println("mission impossible");
			board.deleteThisMove(pair);
//			traceBoard("(2) impossible;",move,pair,board);
			return;
		}
		else {
			int nMax = board.getMaxMoves(pair);
			Pair newPair;
			for (int i = 0; i < nMax; i++) {
				newPair = board.getThisMove(pair, i);
				if (board.isEmpty(newPair))
					nextMove (move+1, newPair, board);
			}
//			traceBoard("(1) deleteThisMove;",move,pair,board);
			board.deleteThisMove(pair);
//			traceBoard("(2) deleteThisMove;",move,pair,board);
		}
	}
	private boolean isImpossibleSituation (Pair pair, Board board) {
		return board.isImpossibleSituation(pair);
	}
	private void printBoard (final Board board) {
		StringBuffer sb = new StringBuffer();
		for (int y = YLIMIT-1; y >= 0; y--) {
			for (int x = 0; x < XLIMIT; x++) {
				sb.append(board.getMoveNumber(x,y));
				sb.append(',');
		}	}
		Output.println(sb.toString());
	}
	private void traceBoard (String msg, int move, Pair pair, final Board board) {
		StringBuffer sb;
		int num;
		Debug.println("traceBoard; "+msg);
		Debug.println("Move "+move+" pair "+pair.getX()+","+pair.getY());
		for (int y = YLIMIT-1; y >= 0; y--) {
			sb = new StringBuffer();
			for (int x = 0; x < XLIMIT; x++) {
				num = board.getMoveNumber(x,y);
				if (num < 10) sb.append(' ');
				sb.append(' ');
				sb.append(num);
			}
			Debug.println(sb.toString());
		}
	}
	public static void main (String[] args) {
		(new Game()).init(args);
	}
}

