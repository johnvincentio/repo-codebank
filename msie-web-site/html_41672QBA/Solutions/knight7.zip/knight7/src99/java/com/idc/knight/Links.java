
package com.idc.knight;

import java.util.*;

public class Links {
	List m_list = new ArrayList();
	public Links() {}
	public int getLength() {return m_list.size();}
	public void add(Pair pair) {m_list.add(pair);}
	public Pair get(int i) {return (Pair) m_list.get(i);}
}

