
package com.idc.knight;

import java.io.*;
import java.sql.Time;

public class Output {
	private static boolean m_bConsole = false;
	private static boolean m_bStatus = false;
	private static boolean m_bFlush = false;

	private static FileWriter m_fw;
	private static BufferedWriter m_bw;
	private static PrintWriter m_out;

	public Output() {}

	public static void setFile () {m_bStatus = m_bConsole = true;}
	public static void setFile (String strFile, boolean bFlush) {
		m_bFlush = bFlush;
		try {
			m_out = new PrintWriter (new BufferedWriter (
							new FileWriter (strFile, false)));
		} catch (IOException e) {
			System.out.println ("Unable to open file :" + strFile + ":");
			return;
		}
		m_bStatus = true;
	}
	public static synchronized void print (String msg) {
		if (! m_bStatus) return;
		if (m_bConsole) {System.out.print (msg); return;}
		m_out.write (msg);
	}
	public static void flush() {m_out.flush();}
//	private static String newLine() {return "\r\n";}
	private static String newLine() {return "\n";}
	public static synchronized void println () {print(newLine());}
	public static synchronized void println (String msg) {
		print(msg + newLine());
		if (m_bFlush) flush();
	}
	public static synchronized void timing (String msg) {
		Time time = new Time(System.currentTimeMillis());
		println (time.toString() + "; " + msg);
	}
}

