
package com.idc.knight;

public class Pair {
	private final int m_x;
	private final int m_y;
	public Pair(int x, int y) {m_x = x; m_y = y;}
	public int getX() {return m_x;}
	public int getY() {return m_y;}
}

