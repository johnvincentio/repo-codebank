
package com.idc.knight;

public class Square implements Constants {
	final private Pair m_pair;
	private int m_nMoveNumber;
	private Links m_links;
	private int m_nExits;
	public Square(Pair pair) {
		m_pair = pair;
		m_nMoveNumber = 0;
		m_nExits = 0;
		m_links = new Links();
		makeLinks();
	}
	private void makeLinks() {
		int x = m_pair.getX();
		int y = m_pair.getY();
		int newX, newY;
		for (int i = 0; i < MAXMOVETYPES; i++) {
			newX = x + XINC[i];
			newY = y + YINC[i];
			if (newX < 0 || newX >= XLIMIT) continue;
			if (newY < 0 || newY >= YLIMIT) continue;
			m_links.add (new Pair(newX,newY));
			m_nExits++;
		}
	}
	public Pair getPair() {return m_pair;}
	public int getMoveNumber() {return m_nMoveNumber;}
	public void setMoveNumber(int move) {m_nMoveNumber = move;}
	public boolean isEmpty() {return m_nMoveNumber < 1;}
	public int getMaxMoves() {return m_links.getLength();}
	public Pair getThisMove(int i) {return m_links.get(i);}
	public void incrementExits() {m_nExits++;}
	public void decrementExits() {m_nExits--;}
	public int getExits() {return m_nExits;}
/*
	public String show() {
		StringBuffer sb = new StringBuffer();
		sb.append("(i,j) ("); sb.append(m_pair.getX());
		sb.append(","); sb.append(m_pair.getY());
		sb.append(") empty "); sb.append(isEmpty());
		sb.append(" exits "); sb.append(getExits());
		return sb.toString();
	}
*/
}

