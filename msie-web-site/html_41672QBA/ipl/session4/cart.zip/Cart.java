package jsp;

import java.util.*;

public class Cart {

	private ArrayList list; 

	public Cart() {emptyCart();}
	public void emptyCart(){ list = new ArrayList(); }

//	public void addItem(Item i) {list.add(i);}

	public void addItem(Item i) {
		Iterator iterator = list.iterator();
		while(iterator.hasNext()) {
			Item item = (Item)iterator.next();
			if(item.getStockid().equals(i.getStockid())) {
				item.setNumitems (item.getNumitems() + i.getNumitems());
				return;
			}
		}
		list.add(i);
	}

	public void updateItem (String id, int newNumber) {
		Iterator iterator = list.iterator();
		while(iterator.hasNext()) {
			Item item = (Item)iterator.next();
			if(item.getStockid().equals(id)) {
				item.setNumitems (newNumber);
				break;
			}
		}
	}

	public void deleteItem(String id) {
		Iterator iterator = list.iterator();
		while(iterator.hasNext()) {
			Item item = (Item)iterator.next();
			if(item.getStockid().equals(id)) {
				iterator.remove();
				break;
			}
		}
	}

	public Iterator getItems() {return list.iterator();}

	public double computeTotal() {
		Iterator iterator = list.iterator();
		double total = 0;
		while(iterator.hasNext()) {
			Item item = (Item)iterator.next();
			total = total + item.getNumitems() * item.getPrice();
		}
		return total;
	}
}

