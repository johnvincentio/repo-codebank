package jsp;

import java.util.*;

public class Catalog {		// catalog of items for sale

	private ArrayList list; 

	public Catalog() {		// need something to sell
		emptyCatalog();
		fillCatalog();
	}

	public void emptyCatalog() {list = new ArrayList();}
	public void fillCatalog() {
		addItem (new Item("Rachmaninov","Piano Concerto No 2","101",20,5.25));
		addItem (new Item("Mahler","Symphony No 6 Tragic","102",15,6.13));
		addItem (new Item("Mendelssohn","Symphony No 3 Scottish","103",12,7.24));
		addItem (new Item("Handel","Messiah","104",35,8.45));
		addItem (new Item("Haydn","Symphony No 100 Military","105",18,4.25));
		addItem (new Item("Mozart","Requiem","106",41,6.74));
		addItem (new Item("Bach","Mass in B Minor","107",21,5.78));
	}
	public void addItem(Item i){list.add(i);}
	public Iterator getItems() {return list.iterator();}
}

