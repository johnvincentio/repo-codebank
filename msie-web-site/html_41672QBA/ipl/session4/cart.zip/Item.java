
package jsp;

public class Item {
	String name;
	String description;
	String stockid;
	double price;
	int numitems;

	public Item(String s, String d, String n, int i, double p){
		name = s;
		description = d;
		stockid = n;
		numitems = i;
		price = p;
	}
	public String getName() {return name;}
	public String getDescription() {return description;}
	public String getStockid() {return stockid;}
	public int getNumitems() {return numitems;}
	public double getPrice() {return price;}
	public void setNumitems (int newItems) {numitems = newItems;}
}

