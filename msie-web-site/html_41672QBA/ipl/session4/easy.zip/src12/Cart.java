package jsp; 
import java.util.*;

public class Cart {
  // Keep the cart items in a java.util.ArrayList
  private ArrayList list; 

  // Constructor sets up the ArrayList instance variable
  public Cart() { list = new ArrayList(); }

  // Setter for the "item" property does an add() on the ArrayList
  public void setItem(String s) { list.add(s); }
  public void setPrice(String s) { list.add(s); }
  public void setQty(String s) { list.add(s); }  

  // Getter for the "items" property". Produce an HTML unordered list
  // that wraps up all the elements in the ArrayList
  public String getItems() {
    String theList =  "<ul>";
    for (int i =  0; i < list.size(); ) {
//      theList = theList + "<li>" + (String) list.get(i);
//      i += 1;
     theList = theList + "<li>" + (String) list.get(i) + "," + (String) list.get(i+1) +
      				"," + (String) list.get(i+2);
      i += 3;      
    }
    return theList + "</ul>";
  }
  
	public String getTotal() {
		int cntr = 0;
		double total = 0;
		int qty = 0;
		double price = 0;
   		for (int i =  0; i < list.size(); i++) {
			if (cntr == 1)
				price = Double.parseDouble((String) list.get(i));
	   		if (cntr == 2)		
				qty = Integer.parseInt((String) list.get(i));						
			cntr++;
			if (cntr > 2) {
				total += price * qty;
				cntr = 0;
			}
		}
		Double dbl = new Double(total);
		return dbl.toString();
	} 
} 
