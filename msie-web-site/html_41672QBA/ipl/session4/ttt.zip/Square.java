/*
    Square.java models a position in the game TicTacToe.
    It knows it's position in the grid and knows it's value,
       either empty, an X or an O.
*/

package jsp;

public class Square {
  final static int SQUARE_X_MARK = 1;
  final static int SQUARE_O_MARK = 2;
  final static int SQUARE_EMPTY = 0;

  private int markValue;
  private int xCoord;
  private int yCoord;

  public Square(int i, int j)
	{xCoord = i; yCoord = j; markValue = SQUARE_EMPTY;}

  public int getXCoord() {return this.xCoord;}
  public int getYCoord() {return this.yCoord;}
  public boolean isEmpty() {return (markValue == SQUARE_EMPTY? true : false);}

  public void setMarkOnSquare(boolean bXType) {
    if (bXType)
      markValue = SQUARE_X_MARK;
    else
      markValue = SQUARE_O_MARK;
  }
  public String getMarkString() {
    if (markValue == SQUARE_X_MARK)
      return "X";
    else if (markValue == SQUARE_O_MARK)
      return "O";
    else
      return " ";
  }
}

