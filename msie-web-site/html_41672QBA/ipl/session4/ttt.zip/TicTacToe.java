
package jsp;

public class TicTacToe {

  private String displayarea;  // messages for the user
  private String idfield;     // player turn message

  private Square square[][];    // tictactoe grid.
  private int marks[][];        // keeps a count for each square.
  private int iaTotals[];       // 8 buckets for 8 winning scenarios
  private boolean bXPlayer = true;  // true is X is to play.
  private boolean bAllover = false; // disable app when game over

  public TicTacToe() {
    square = new Square[3][3];
    marks = new int[3][3];
    reStart();
  }
	public void reStart() {
    for (int row = 0; row < 3; row++) {
      for (int col = 0; col < 3; col++) {
        square[row][col] = new Square(row, col);
        marks[row][col] = 0;                        // initialize
      }
    }
    iaTotals = new int[8];
    for (int i=0; i<8; i++) iaTotals[i] = 0;       // initialize
    bXPlayer = true;
    bAllover = false;
    setToPlayer();
	}

	public String getDisplayarea() {return displayarea;}
	public String getIdfield() {return idfield;}
	public String getMark (int x, int y) {
		return square[x-1][y-1].getMarkString();}

	private void setAreaMessage(String msg) {displayarea = msg;}
	private void setIDMessage(String msg) {idfield = msg;}

  private void setToPlayer () {
    if (bXPlayer) {
      setIDMessage("Player X");
      setAreaMessage("Player X - Please enter your x,y coordinates below");
    }
    else {
      setIDMessage("Player O");
      setAreaMessage("Player O - Please enter your x,y coordinates below");
    }
  }
  private void setWonGame () {
    if (bXPlayer)
      setAreaMessage("Player X just won the game!");
    else
      setAreaMessage("Player O always was going to win!");
    bAllover = true;
  }
  private void setDrawnGame () {
    setIDMessage("");
    setAreaMessage("The game is a draw");
    bAllover = true;
  }

  public void makeMove(int xpos, int ypos) {
    if (bAllover) {
      setAreaMessage("The game is over!");
      return;
    }
    if (xpos < 1 || xpos > 3) {
      setAreaMessage("The x position of " + xpos + " is invalid");
      return;
    }
    if (ypos < 1 || ypos > 3) {
      setAreaMessage("The y position of " + ypos + " is invalid");
      return;
    }
    Square sq = square[xpos-1][ypos-1];
    if (! sq.isEmpty()) {
      setAreaMessage("That position is occupied!");
      return;
    }
    sq.setMarkOnSquare(bXPlayer);  // mark the grid

//  Recalculate the buckets
//  There are only 8 possible winning scenarios, so assign a bucket for each.
    int x = sq.getXCoord();
    int y = sq.getYCoord();
    int inc = bXPlayer ? 100 : 1000;
    marks[x][y] = inc;     // mark the current grid position
    iaTotals[0] = marks[0][0] + marks[0][1] + marks[0][2];  // (0,0) is the top left
    iaTotals[1] = marks[1][0] + marks[1][1] + marks[1][2];
    iaTotals[2] = marks[2][0] + marks[2][1] + marks[2][2];
    iaTotals[3] = marks[0][0] + marks[1][0] + marks[2][0];
    iaTotals[4] = marks[0][1] + marks[1][1] + marks[2][1];
    iaTotals[5] = marks[0][2] + marks[1][2] + marks[2][2];
    iaTotals[6] = marks[0][0] + marks[1][1] + marks[2][2];
    iaTotals[7] = marks[0][2] + marks[1][1] + marks[2][0];

    for (int i=0; i<8; i++) { // look for a won game
//      System.out.println(" (i,total) ("+i+","+iaTotals[i]+")");
      if (iaTotals[i] == inc * 3) { // X win = 300, O win = 3000
        setWonGame();
        return;
      }
    }

    boolean draw = true;           // look for a drawn game
    for (int i=0; i<8; i++) {		// = 1100, 1200 or 2100
      if (! ((iaTotals[i] > 1000) && ((iaTotals[i] % 1000) != 0))) {
        draw = false;
		break;
      }
    }
	if (draw) {
      setDrawnGame();
      return;
	}
     bXPlayer = ! bXPlayer;
     setToPlayer();
  }
}

