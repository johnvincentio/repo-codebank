
import junit.framework.*;

public class AllTests {		// only exists for junit

	public static void main (String[] args) {
		junit.textui.TestRunner.run (suite());
	}
	public static Test suite ( ) {
		TestSuite suite= new TestSuite("All JUnit Tests");
		suite.addTest(new TestSuite(Rig.class));	// add more if you like
	    return suite;
	}
}
