
public class Main {

	public Main() {
		Debug.setFile();
		Rig rig = new Rig();
		rig.getOnWithIt();
	}
	public static void main (String[] args) {
		Main main = new Main();
	}
}

