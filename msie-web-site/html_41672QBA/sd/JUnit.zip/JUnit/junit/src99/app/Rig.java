
/*
	Rig.java; This class is intended to be used as a test rig.
		It is intended that various classes be tested thoroughly by
		the rig before being deployed to the application development
		team.
		This class can be used to test with junit as well as manually.
		Many, many more tests should be added before the tested classes
		could be considered tested.
		Have fun!!!
*/

import junit.framework.*;		// junit

public class Rig extends TestCase {		// junit: extends TestCase
	private String m_strName;	// mimic application behaviour - player name
	private String m_rack;		// ditto; player rack
	private String m_message;	// ditto; buffer going onto/coming off the socket

	public Rig() {}

	private void setPlayer(String strName) {m_strName = strName;}	// set name
	public void sendMessage(String msg) {m_message = msg;}	// send to buffer
	public String getMessage() {return m_message;}	// get from buffer
	private char setLetter (int num) {return (char) (num + 64);}
	public void setMessagesArea (String msg) {Debug.println("Scores: "+msg);}
	public String getRack () {return m_rack;}
	public void setRack (String msg) {m_rack = msg;}
	public void getOnWithIt() {		// list the tests - non junit
		makeRack();
		processMessage (getMessage());
		makeScores();
		processMessage (getMessage());
	}
//
//	These are just samples. I really need lots of different instances of makeRack
//		and makeScores to test all possible scenarios. This is just to gain
//		some understanding of junit.
//
// makeRack() - test the methodology
//
	public void makeRack() {
		setPlayer("Napolean");
		ScrabblePacketWriter pw = new ScrabblePacketWriter(Constants.GAME_RACK);
		pw.append(m_strName);
		pw.append(6); pw.append(20); pw.append(9);
		pw.append(16); pw.append(21); pw.append(13);
		pw.append(8);
		sendMessage(pw.getString());
	}
//
// makeScores() - test the methodology
//
	public void makeScores() {
		ScrabblePacketWriter pw = new ScrabblePacketWriter(Constants.GAME_SCORES);
		pw.append(1); pw.append("Mozart"); pw.append(71);
		pw.append(2); pw.append("Rachmaninov"); pw.append(81);
		pw.append(3); pw.append("Bach"); pw.append(70);
		pw.append(4); pw.append("Chopin"); pw.append(65);
		sendMessage(pw.getString());
	}
//
// processMessage() - test the methodology - get from buffer (socket).
//
	public void processMessage (final String strMessage) {
		StringBuffer buf = new StringBuffer();
		ScrabblePacketReader pr = new ScrabblePacketReader(strMessage);
		int keyid = pr.getNextInt();
		switch (keyid) {
			case Constants.GAME_RACK:
				String strtmp = pr.getNext();
				buf = new StringBuffer();
				while (pr.hasNext()) {
					buf.append(setLetter(pr.getNextInt()));
				}
				setRack (buf.toString());
				break;
			case Constants.GAME_SCORES:
				while (pr.hasNext(3)) {
					buf = new StringBuffer();
					buf.append(pr.getNext()); buf.append(",");
					buf.append(pr.getNext()); buf.append(",");
					buf.append(pr.getNext());
					setMessagesArea (buf.toString());
				}
				break;
			default:
				break;
		}
	}
//
//	junit code. Should pile on the tests. Test every scenario. test boundary
//		conditions, test non standard situations.
//
	public static Test suite() {return new TestSuite(Rig.class);}	// junit
	protected void setUp() {			// junit initialization
		Debug.setFile();
	}
	public void testRack() {			// junit only
		Debug.println("--- testRack");
		makeRack();
		Debug.println(getMessage());
		assertEquals(getMessage(),"200:Napolean:6:20:9:16:21:13:8");
		processMessage (getMessage());
		assertEquals(getRack(),"FTIPUMH");
	}
	public void testScores() {		// junit only
		Debug.println("--- testScores");
		makeScores();
		Debug.println(getMessage());
		assertEquals(getMessage(),
				"300:1:Mozart:71:2:Rachmaninov:81:3:Bach:70:4:Chopin:65");
		processMessage (getMessage());
	}
	public static void main (String[] args) {		// junit only
		junit.textui.TestRunner.run(suite());
	}
}

