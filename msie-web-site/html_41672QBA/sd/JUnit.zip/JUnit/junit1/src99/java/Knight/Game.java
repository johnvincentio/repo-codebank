
package Knight;

import Utils.Debug;

public class Game {

	public Game() {}

	public static void main (String args[]) {
		Knight knight = new Knight();
		knight.initapp(args);
		String strMsg;
		while ((strMsg = knight.getNextSolution()) != null) {
			Debug.println(strMsg);
		}
		Debug.flush();
	}
}

