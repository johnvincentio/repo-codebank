
package Knight;

import java.util.*;

public class JVList {
	private List m_list;
	private int m_nCurrentItem = 0;

	public JVList () {m_list = new ArrayList();}

	public void addItem (Object obj) {m_list.add(obj);}
	public Object getNext() {
		if (m_nCurrentItem >= m_list.size())
			return null;
		else
			return m_list.get(m_nCurrentItem++);
	}
}

