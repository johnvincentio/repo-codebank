
package Knight;

public class KException extends Exception {

	public KException() {}

	public KException(String message) {
		super (message);
	}
}

