
package Knight;

import Utils.Debug;

public class Knight {
	static final int XLIMIT = 8;
	static final int YLIMIT = 8;
	static final int XYLIMIT = XLIMIT * YLIMIT;
	static final int[] Xinc = {1,2,2,1,-1,-2,-2,-1};
	static final int[] Yinc = {2,1,-1,-2,-2,-1,1,2};
	static final int MAXMOVETYPES = 8;

	private JVList m_jvlist;
	private boolean m_bLimitedSolutions = false;
	private int m_nFindSolutions = 0;
	private int m_nFoundSolutions = 0;

	public Knight() {}

	public void initapp (String args[]) {
		int nSolutions = (int) new Integer(args[0]).intValue();
		m_nFindSolutions = nSolutions;
		if (m_nFindSolutions > 0) m_bLimitedSolutions = true;

		if (args[1].toLowerCase().equals("all")) {
			System.out.println("allMain");
			for (int x = 0; x < XLIMIT; x++) {
				for (int y = 0; y < YLIMIT; y++)
					start(x,y);
			}
			Debug.timing ("There are no more possible solutions. Exiting...");
			Debug.flush();
		}
		else {
			System.out.println("oneMain");
			int x = (new Integer(args[1]).intValue());
			int y = (new Integer(args[2]).intValue());
			start(x,y);
		}
	}

	private void start (int x, int y) {
		String strFile = "Knight_" + x + "_" + y + ".txt";
		Debug.setFile(strFile,false);

		int board[][] = new int[XLIMIT][YLIMIT];
		m_jvlist = new JVList();
		try {
			Debug.timing("Starting ("+x+","+y+")"); Debug.flush();
			nextMove (1,x,y,board);
		}
		catch (KException kex) {
			Debug.timing("Finished ("+x+","+y+")"); Debug.flush();
		}
	}
	private void nextMove (int move, int x, int y, int board[][]) throws KException {
		board[x][y] = move;
		if (move >= XYLIMIT){
			String strBrd = makeStringBoard (board);
			if (m_bLimitedSolutions) {
				m_jvlist.addItem(strBrd);
				m_nFoundSolutions++;
				if (m_nFoundSolutions >= m_nFindSolutions)
					throw new KException();
			}
			else {
				Debug.println(strBrd); Debug.flush();
			}
		}
		int newX, newY;
		for (int i = 0; i < MAXMOVETYPES; i++) {
			newX = x + Xinc[i]; newY = y + Yinc[i];
			if (newX < 0 || newX >= XLIMIT) continue;
			if (newY < 0 || newY >= YLIMIT) continue;
			if (board[newX][newY] < 1)
				nextMove (move+1, newX, newY, board);
		}
		board[x][y] = 0;
	}
	private String makeStringBoard (int board[][]) {
		StringBuffer sb = new StringBuffer();
		for (int y = YLIMIT-1; y >= 0; y--) {
			for (int x = 0; x < XLIMIT; x++) {
				sb.append(board[x][y]); sb.append(',');
		}	}
		return sb.toString();
	}
	public String getNextSolution() {
		return (String) m_jvlist.getNext();
	}
}


