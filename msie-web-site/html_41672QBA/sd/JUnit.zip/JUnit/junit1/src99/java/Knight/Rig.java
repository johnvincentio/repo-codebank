
package Knight;

import junit.framework.*;		// junit
import Utils.Debug;

public class Rig extends TestCase {		// junit: extends TestCase

	public Rig() {}

	public static Test suite() {return new TestSuite(Rig.class);}
	protected void setUp() {}
	public void testKnight1() {
		Knight knight;
		Debug.println("--- testKnight(0,0)");
		knight = new Knight();
		String[] strgs = new String[3];
		strgs[0] = "5";
		strgs[1] = "0";
		strgs[2] = "0";
		knight.initapp(strgs);
		String strAnswer;
		strAnswer = "52,47,56,45,54,5,22,13,57,44,53,4,23,14,25,6,48,51,46,55,26,21,12,15,43,58,3,50,41,24,7,20,36,49,42,27,62,11,16,29,59,2,37,40,33,28,19,8,38,35,32,61,10,63,30,17,1,60,39,34,31,18,9,64,";
		assertEquals(knight.getNextSolution(),strAnswer);
		strAnswer = "58,37,54,39,56,5,22,13,53,40,57,4,23,14,25,6,36,59,38,55,26,21,12,15,41,52,3,34,43,24,7,20,60,35,42,27,48,11,16,29,51,2,47,44,33,28,19,8,46,61,32,49,10,63,30,17,1,50,45,62,31,18,9,64,";
		assertEquals(knight.getNextSolution(),strAnswer);
		strAnswer = "52,37,56,39,54,5,22,13,57,40,53,4,23,14,25,6,36,51,38,55,26,21,12,15,41,58,3,34,43,24,7,20,50,35,42,27,62,11,16,29,59,2,47,44,33,28,19,8,46,49,32,61,10,63,30,17,1,60,45,48,31,18,9,64,";
		assertEquals(knight.getNextSolution(),strAnswer);
		strAnswer = "40,49,36,51,38,5,22,13,35,52,39,4,23,14,25,6,48,41,50,37,26,21,12,15,53,34,3,46,55,24,7,20,42,47,54,27,62,11,16,29,33,2,59,56,45,28,19,8,58,43,32,61,10,63,30,17,1,60,57,44,31,18,9,64,";
		assertEquals(knight.getNextSolution(),strAnswer);
		strAnswer = "52,35,56,37,54,5,22,13,57,38,53,4,23,14,25,6,34,51,36,55,26,21,12,15,39,58,3,46,41,24,7,20,50,33,40,27,62,11,16,29,59,2,45,42,47,28,19,8,44,49,32,61,10,63,30,17,1,60,43,48,31,18,9,64,";
		assertEquals(knight.getNextSolution(),strAnswer);
	}
	public static void main (String[] args) {
		junit.textui.TestRunner.run(suite());
	}
}

