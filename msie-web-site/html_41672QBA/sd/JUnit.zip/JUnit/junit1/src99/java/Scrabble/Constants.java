
package Scrabble;

public class Constants {
	public static final int GAME_RACK = 200;
	public static final int GAME_SCORES = 300;
}

