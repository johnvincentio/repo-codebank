
package Utils;

import java.io.*;
import java.sql.Time;

public class Debug {
	private static boolean m_bConsole = false;
	private static boolean m_bStatus = false;
	private static PrintWriter m_out;

	public Debug() {}

	public static void setFile () {m_bStatus = m_bConsole = true;}
	public static void setFile (String strFile, boolean bValue) {
		try {
			m_out = new PrintWriter (new BufferedWriter (
							new FileWriter (strFile, bValue)));
		} catch (IOException e) {
			System.out.println ("Unable to open file :" + strFile + ":");
			return;
		}
		m_bStatus = true;
	}
	public static synchronized void print (String msg) {
		if (! m_bStatus) return;
		if (m_bConsole) {System.out.print (msg); return;}
		m_out.write (msg);
	}
	public static synchronized void flush() {
		if (! m_bConsole) m_out.flush();}
	private static String newLine() {return "\r\n";}
	public static synchronized void println () {print(newLine());}
	public static synchronized void println (String msg) {print(msg + newLine());}
	public static synchronized void timing (String msg) {
		Time time = new Time(System.currentTimeMillis());
		println (time.toString() + "; " + msg);
	}
}

