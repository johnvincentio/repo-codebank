
package Wordgame;

import java.io.*;
import java.util.*;

public class Dictionary {
	private String m_strDictname;
	private List m_dict = new ArrayList();

	public Dictionary() {}
	public boolean setupDictionary(String strName) {
		m_strDictname = strName;
		BufferedReader bf;
		String strText;
		try {
			bf = new BufferedReader(new FileReader(m_strDictname));
			while ((strText = bf.readLine()) != null) {
				m_dict.add(strText.toLowerCase());
			}
		}
		catch (IOException ex) {
			return false;
		}
		return true;
	}
	public int doWordSearch(String strLetters) {
		String strDictWord;
		int nTotal = 0;
		for (int i=0; i<m_dict.size(); i++) {
			strDictWord = ((String)m_dict.get(i));
			if (checkWord (strLetters, strDictWord)) {
				nTotal++;
			}
		}
		return nTotal;
	}
	private boolean checkWord (String strLetters, String strDictWord) {
		LetterSlave lsd, lsl;
		boolean bFound = false;

		List listLetters = makeLetters (strLetters);
		List dictWord = makeLetters (strDictWord);
		for (int i=0; i<dictWord.size(); i++) { //for each letter in dict word
			bFound = false;
			lsd = (LetterSlave) dictWord.get(i);
			for (int j=0; j<listLetters.size(); j++) {
				lsl = (LetterSlave) listLetters.get(j);
				if ((lsd.getInt() == lsl.getInt()) && (! lsl.getBool())) {
					lsl.setBool(true);
					bFound = true;
					break;
				}
			}
			if (! bFound) return false;
		}
		return true;
	}
	private List makeLetters (String strLetters) {
		List list = new ArrayList();
		StringBuffer sb = new StringBuffer(strLetters);
		for (int i=0; i<sb.length(); i++) {
			list.add (new LetterSlave(sb.charAt(i)));
		}
		return list;
	}
	private class LetterSlave {
		private char m_ch;
		private int m_int;
		private boolean m_bool;
		public LetterSlave(char ch) {
			m_ch = ch;
			m_int = (int) ch;
			m_bool = false;
		}
		public void setBool(boolean bool) {m_bool = bool;}
		public boolean getBool() {return m_bool;}
		public int getInt() {return m_int;}
	}
}

