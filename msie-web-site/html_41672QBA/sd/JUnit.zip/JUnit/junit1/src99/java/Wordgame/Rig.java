
package Wordgame;

import junit.framework.*;		// junit
import Utils.Debug;

public class Rig extends TestCase {		// junit: extends TestCase

	public Rig() {}

	public static Test suite() {return new TestSuite(Rig.class);}
	protected void setUp() {			// junit initialization
		Debug.setFile();
	}
	public void testNoDictionary() {
		Debug.println("--- testNoDictionary");
		Dictionary dict = new Dictionary();
		boolean bExists = dict.setupDictionary("abcd.acb");
		assertEquals(bExists,false);
	}
	public void testDictionary() {
		Debug.println("--- testDictionary");
		Dictionary dict = new Dictionary();
		boolean bExists = dict.setupDictionary("Unabr.dict");
		assertEquals(bExists,true);
	}
	public void testWord1() {
		Dictionary dict;
		boolean bExists;
		int nWords;
		Debug.println("--- testWord1");
		dict = new Dictionary();
		bExists = dict.setupDictionary("Unabr.dict");
		assertEquals(bExists,true);
		nWords = dict.doWordSearch ("Napolean");
		assertEquals(nWords,62);
	}
	public void testWord2() {
		Dictionary dict;
		boolean bExists;
		int nWords;
		dict = new Dictionary();
		bExists = dict.setupDictionary("Unabr.dict");
		assertEquals(bExists,true);
		nWords = dict.doWordSearch ("Alfred the Great");
		assertEquals(nWords,349);
	}
	public void testWord3() {
		Dictionary dict;
		boolean bExists;
		int nWords;
		dict = new Dictionary();
		bExists = dict.setupDictionary("Unabr.dict");
		assertEquals(bExists,true);
		nWords = dict.doWordSearch ("Sir Isaac Newton");
		assertEquals(nWords,953);
	}
	public void testWord4() {
		Dictionary dict;
		boolean bExists;
		int nWords;
		dict = new Dictionary();
		bExists = dict.setupDictionary("Unabr.dict");
		assertEquals(bExists,true);
		nWords = dict.doWordSearch ("Albert Einstein");
		assertEquals(nWords,402);
	}
	public void testWord5() {
		Dictionary dict;
		boolean bExists;
		int nWords;
		dict = new Dictionary();
		bExists = dict.setupDictionary("Unabr.dict");
		assertEquals(bExists,true);
		nWords = dict.doWordSearch ("Socrates");
		assertEquals(nWords,132);
	}
	public void testWord6() {
		Dictionary dict;
		boolean bExists;
		int nWords;
		dict = new Dictionary();
		bExists = dict.setupDictionary("Unabr.dict");
		assertEquals(bExists,true);
		nWords = dict.doWordSearch ("Euclid");
		assertEquals(nWords,7);
	}
	public void testWord7() {
		Dictionary dict;
		boolean bExists;
		int nWords;
		dict = new Dictionary();
		bExists = dict.setupDictionary("Unabr.dict");
		assertEquals(bExists,true);
		nWords = dict.doWordSearch ("Alexander the Great");
		assertEquals(nWords,62);
	}
	public void testWord8() {
		Dictionary dict;
		boolean bExists;
		int nWords;
		dict = new Dictionary();
		bExists = dict.setupDictionary("Unabr.dict");
		assertEquals(bExists,true);
		nWords = dict.doWordSearch ("Ramses");
		assertEquals(nWords,62);
	}
	public static void main (String[] args) {		// junit only
		junit.textui.TestRunner.run(suite());
	}
}

